
const state = {
}

export default state
